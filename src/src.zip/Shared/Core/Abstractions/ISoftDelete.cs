namespace RhSensoERP.Shared.Core.Abstractions;

/// <summary>Marca entidades que suportam soft delete.</summary>
public interface ISoftDelete
{
    /// <summary>Indica se o registro est� logicamente exclu�do.</summary>
    bool IsDeleted { get; set; }

    /// <summary>Data e hora da exclus�o l�gica.</summary>
    DateTime? DeletedAt { get; set; }

    /// <summary>Usu�rio que excluiu o registro.</summary>
    string? DeletedBy { get; set; }
}