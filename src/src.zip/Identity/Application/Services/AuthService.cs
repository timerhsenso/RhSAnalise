﻿// src/Identity/Application/Services/AuthService.cs
// ============================================================================
// REFATORAÇÃO FASE 1 - CRÍTICO
// ============================================================================
// Alterações implementadas:
// 1. ✅ Resolução de tenant via ITenantContext
// 2. ✅ Determinação do AuthMode consultando SEG_SecurityPolicy do banco
// 3. ✅ Busca de usuário por email ou cdusuario conforme modo
// 4. ✅ Remoção de AuthStrategy do request (segurança)
// ============================================================================

using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RhSensoERP.Identity.Application.Configuration;
using RhSensoERP.Identity.Application.DTOs.Auth;
using RhSensoERP.Identity.Domain.Entities;
using RhSensoERP.Identity.Infrastructure.Persistence;
using RhSensoERP.Shared.Core.Abstractions;
using RhSensoERP.Shared.Core.Common;

// Alias para evitar confusão com o namespace BCrypt.Net
using BCryptNet = BCrypt.Net.BCrypt;

namespace RhSensoERP.Identity.Application.Services;

/// <summary>
/// Implementação do serviço de autenticação com suporte a múltiplas estratégias.
/// Responsável por login, refresh token, logout e validação de senhas.
/// </summary>
public sealed class AuthService : IAuthService
{
    private readonly IdentityDbContext _db;
    private readonly IJwtService _jwtService;
    private readonly IMapper _mapper;
    private readonly IDateTimeProvider _dateTimeProvider;
    private readonly ITenantContext _tenantContext; // ✅ NOVO
    private readonly ILogger<AuthService> _logger;
    private readonly AuthSettings _authSettings;
    private readonly SecurityPolicySettings _securityPolicy;

    public AuthService(
        IdentityDbContext db,
        IJwtService jwtService,
        IMapper mapper,
        IDateTimeProvider dateTimeProvider,
        ITenantContext tenantContext, // ✅ NOVO
        ILogger<AuthService> logger,
        IOptions<AuthSettings> authSettings,
        IOptions<SecurityPolicySettings> securityPolicy)
    {
        _db = db;
        _jwtService = jwtService;
        _mapper = mapper;
        _dateTimeProvider = dateTimeProvider;
        _tenantContext = tenantContext; // ✅ NOVO
        _logger = logger;
        _authSettings = authSettings.Value;
        _securityPolicy = securityPolicy.Value;

        EnsureDefaultStrategiesExist();
    }

    /// <summary>
    /// Garante que estratégias padrão existem caso o appsettings não as defina.
    /// </summary>
    private void EnsureDefaultStrategiesExist()
    {
        if (_authSettings.Strategies.Count == 0)
        {
            _logger.LogWarning(
                "⚠️ INICIALIZAÇÃO: AuthSettings.Strategies vazio. Criando configurações padrão.");

            _authSettings.Strategies["Legacy"] = new StrategyConfig
            {
                Enabled = true,
                UseBCrypt = false,
                SyncWithUserSecurity = true,
                RequireEmailConfirmation = false,
                Require2FA = false
            };

            _authSettings.Strategies["SaaS"] = new StrategyConfig
            {
                Enabled = true,
                UseBCrypt = true,
                SyncWithUserSecurity = false,
                RequireEmailConfirmation = true,
                Require2FA = false
            };

            _authSettings.Strategies["ADWin"] = new StrategyConfig
            {
                Enabled = false,
                UseBCrypt = false,
                SyncWithUserSecurity = false,
                RequireEmailConfirmation = false,
                Require2FA = false
            };

            _logger.LogInformation(
                "✅ INICIALIZAÇÃO: Estratégias padrão criadas: {Strategies}",
                string.Join(", ", _authSettings.Strategies.Keys));
        }
        else
        {
            _logger.LogInformation(
                "✅ INICIALIZAÇÃO: Estratégias carregadas do appsettings: {Strategies}",
                string.Join(", ", _authSettings.Strategies.Keys));
        }

        if (string.IsNullOrWhiteSpace(_authSettings.DefaultStrategy))
        {
            _authSettings.DefaultStrategy = "Legacy";
            _logger.LogWarning(
                "⚠️ INICIALIZAÇÃO: DefaultStrategy vazio. Definido como '{DefaultStrategy}'",
                _authSettings.DefaultStrategy);
        }

        if (!_authSettings.Strategies.ContainsKey(_authSettings.DefaultStrategy))
        {
            var firstEnabled = _authSettings.Strategies
                .FirstOrDefaultAsync(s => s.Value.Enabled).Key ?? "Legacy";

            _logger.LogWarning(
                "⚠️ INICIALIZAÇÃO: DefaultStrategy '{DefaultStrategy}' não encontrada. Usando '{Fallback}'",
                _authSettings.DefaultStrategy,
                firstEnabled);

            _authSettings.DefaultStrategy = firstEnabled;
        }
    }

    /// <summary>
    /// Autentica um usuário com credenciais e retorna tokens JWT.
    /// ✅ REFATORADO: Implementa lógica correta conforme documento de requisitos.
    /// </summary>
    public async Task<Result<AuthResponse>> LoginAsync(
        LoginRequest request,
        string ipAddress,
        string? userAgent = null,
        CancellationToken ct = default)
    {
        try
        {
            _logger.LogInformation("🚀 AuthService.LoginAsync INICIADO para {LoginIdentifier}", request.LoginIdentifier);

            // ============================================================================
            // ETAPA 1: RESOLVER TENANT
            // ============================================================================
            var tenantId = _tenantContext.TenantId;
            Guid? tenantGuid = null;

            if (!string.IsNullOrEmpty(tenantId) && Guid.TryParse(tenantId, out var parsedTenantId))
            {
                tenantGuid = parsedTenantId;
                _logger.LogInformation("✅ ETAPA 1: Tenant resolvido - TenantId: {TenantId}", tenantId);
            }
            else
            {
                _logger.LogWarning("⚠️ ETAPA 1: Tenant não resolvido. Usando configuração global.");
            }

            // ============================================================================
            // ETAPA 2: DETERMINAR AUTHMODE
            // ============================================================================
            var authMode = await DeterminarAuthModeAsync(tenantGuid, ct);
            _logger.LogInformation("✅ ETAPA 2: AuthMode determinado: '{AuthMode}'", authMode);

            // ============================================================================
            // ETAPA 3: LOCALIZAR USUÁRIO
            // ============================================================================
            var usuario = await LocalizarUsuarioAsync(request.LoginIdentifier, authMode, ct);

            if (usuario == null)
            {
                _logger.LogWarning("❌ ETAPA 3: Usuário '{LoginIdentifier}' NÃO ENCONTRADO", request.LoginIdentifier);
                return Result<AuthResponse>.Failure("INVALID_CREDENTIALS", "Usuário ou senha inválidos.");
            }

            _logger.LogInformation("✅ ETAPA 3: Usuário encontrado - CdUsuario: {CdUsuario}, FlAtivo: {FlAtivo}",
                usuario.CdUsuario, usuario.FlAtivo);

            // Verificar se usuário está ativo
            if (usuario.FlAtivo != 'S')
            {
                _logger.LogWarning("❌ LOGIN: Usuário {CdUsuario} INATIVO", usuario.CdUsuario);
                return Result<AuthResponse>.Failure("USER_INACTIVE", "Usuário inativo.");
            }

            // ============================================================================
            // ETAPA 4: CARREGAR SEGURANÇA MODERNA
            // ============================================================================
            _logger.LogInformation("🔍 ETAPA 4: Buscando UserSecurity para IdUsuario={IdUsuario}", usuario.Id);
            var userSecurity = await GetOrCreateUserSecurityAsync(usuario, ct);
            _logger.LogInformation("✅ ETAPA 4: UserSecurity obtido. Id={Id}, LockoutEnd={LockoutEnd}",
                userSecurity.Id, userSecurity.LockoutEnd);

            // ============================================================================
            // ETAPA 5: VERIFICAR LOCKOUT
            // ============================================================================
            if (userSecurity.LockoutEnd.HasValue && userSecurity.LockoutEnd > _dateTimeProvider.UtcNow)
            {
                var remainingMinutes = (userSecurity.LockoutEnd.Value - _dateTimeProvider.UtcNow).TotalMinutes;
                _logger.LogWarning("🔒 ETAPA 5: Conta BLOQUEADA até {LockoutEnd}", userSecurity.LockoutEnd);

                await RegisterFailedLoginAsync(userSecurity, ipAddress, userAgent, "Account locked", ct);

                return Result<AuthResponse>.Failure(
                    "ACCOUNT_LOCKED",
                    $"Conta bloqueada. Tente novamente em {Math.Ceiling(remainingMinutes)} minutos.");
            }

            _logger.LogInformation("✅ ETAPA 5: Lockout verificado - Conta não está bloqueada");

            // Obter configuração da estratégia
            if (!_authSettings.Strategies.TryGetValue(authMode, out var strategyConfig))
            {
                _logger.LogError(
                    "❌ LOGIN: Estratégia '{AuthMode}' não encontrada. Disponíveis: {Available}",
                    authMode,
                    string.Join(", ", _authSettings.Strategies.Keys));

                return Result<AuthResponse>.Failure(
                    "INVALID_AUTH_STRATEGY",
                    "Modo de autenticação inválido. Contate o administrador.");
            }

            if (!strategyConfig.Enabled)
            {
                _logger.LogWarning("⚠️ LOGIN: Estratégia '{AuthMode}' está DESABILITADA", authMode);
                return Result<AuthResponse>.Failure(
                    "AUTH_STRATEGY_DISABLED",
                    "O modo de autenticação está desabilitado.");
            }

            // ============================================================================
            // ETAPA 6: VALIDAR CREDENCIAIS
            // ============================================================================
            _logger.LogInformation("🔐 ETAPA 6: Validando senha com estratégia '{AuthMode}'", authMode);
            var isValidPassword = ValidatePassword(usuario, userSecurity, request.Senha, authMode);

            if (!isValidPassword)
            {
                _logger.LogWarning("❌ ETAPA 6: Senha INVÁLIDA para {CdUsuario}", usuario.CdUsuario);

                userSecurity.IncrementAccessFailedCount();

                if (userSecurity.AccessFailedCount >= _securityPolicy.MaxFailedAccessAttempts)
                {
                    var lockoutEnd = _dateTimeProvider.UtcNow.AddMinutes(_securityPolicy.LockoutDurationMinutes);
                    userSecurity.LockUntil(lockoutEnd, $"Max failed attempts ({_securityPolicy.MaxFailedAccessAttempts})");

                    _logger.LogWarning(
                        "🔒 LOGIN: Conta {CdUsuario} BLOQUEADA até {LockoutEnd} após {Attempts} tentativas",
                        usuario.CdUsuario,
                        lockoutEnd,
                        userSecurity.AccessFailedCount);
                }

                await UpdateUserSecurityInDatabaseAsync(userSecurity, ct);
                await RegisterFailedLoginAsync(userSecurity, ipAddress, userAgent, "Invalid password", ct);

                return Result<AuthResponse>.Failure("INVALID_CREDENTIALS", "Usuário ou senha inválidos.");
            }

            _logger.LogInformation("✅ ETAPA 6: Credenciais VÁLIDAS");

            // Validações de segurança adicionais
            if (strategyConfig.RequireEmailConfirmation && !userSecurity.EmailConfirmed)
            {
                _logger.LogWarning("⚠️ LOGIN: E-mail não confirmado para {CdUsuario}", usuario.CdUsuario);
                return Result<AuthResponse>.Failure(
                    "EMAIL_NOT_CONFIRMED",
                    "E-mail não confirmado. Verifique sua caixa de entrada.");
            }

            if (strategyConfig.Require2FA && !userSecurity.TwoFactorEnabled)
            {
                _logger.LogWarning("⚠️ LOGIN: 2FA obrigatório mas não configurado para {CdUsuario}", usuario.CdUsuario);
                return Result<AuthResponse>.Failure(
                    "2FA_REQUIRED",
                    "Autenticação de dois fatores obrigatória. Configure 2FA antes de fazer login.");
            }

            // ============================================================================
            // ETAPA 7: REGISTRAR AUDITORIA
            // ETAPA 8: RESET/INCREMENTO DE TENTATIVAS
            // ============================================================================
            _logger.LogInformation("✅ ETAPA 7-8: Resetando tentativas e registrando auditoria");

            userSecurity.ResetAccessFailedCount();
            userSecurity.RegisterSuccessfulLogin(ipAddress);

            await UpdateUserSecurityInDatabaseAsync(userSecurity, ct);
            await RegisterSuccessfulLoginAsync(userSecurity, ipAddress, userAgent, ct);

            // ============================================================================
            // ETAPA 9: CARREGAR PERMISSÕES
            // ============================================================================
            // TODO: Implementar na FASE 2
            _logger.LogInformation("⚠️ ETAPA 9: Carregamento de permissões não implementado (FASE 2)");

            // ============================================================================
            // ETAPA 10: CRIAR SESSÃO / TOKEN / CLAIMS
            // ============================================================================
            _logger.LogInformation("✅ ETAPA 10: Gerando tokens JWT");

            var accessToken = _jwtService.GenerateAccessToken(usuario, userSecurity);
            var refreshToken = await _jwtService.GenerateRefreshTokenAsync(
                userSecurity.Id,
                ipAddress,
                request.DeviceId,
                request.DeviceName,
                ct);

            // Mapear informações do usuário
            var userInfo = new UserInfoDto
            {
                Id = usuario.Id,
                CdUsuario = usuario.CdUsuario,
                DcUsuario = usuario.DcUsuario,
                Email = usuario.Email_Usuario,
                NoMatric = usuario.NoMatric,
                CdEmpresa = usuario.CdEmpresa,
                CdFilial = usuario.CdFilial,
                TenantId = usuario.TenantId,
                TwoFactorEnabled = userSecurity.TwoFactorEnabled,
                MustChangePassword = userSecurity.MustChangePassword
            };

            var response = new AuthResponse
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                TokenType = "Bearer",
                ExpiresIn = 900, // 15 minutos em segundos
                ExpiresAt = _dateTimeProvider.UtcNow.AddMinutes(15),
                User = userInfo
            };

            _logger.LogInformation("✅ LOGIN: Tokens gerados com sucesso para {CdUsuario}", usuario.CdUsuario);

            return Result<AuthResponse>.Success(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Erro ao processar login: {LoginIdentifier}", request.LoginIdentifier);
            return Result<AuthResponse>.Failure("LOGIN_ERROR", "Erro ao processar login. Tente novamente.");
        }
    }

    // ============================================================================
    // MÉTODOS AUXILIARES - NOVOS
    // ============================================================================

    /// <summary>
    /// ✅ NOVO: Determina o AuthMode consultando SEG_SecurityPolicy do banco.
    /// Ordem de prioridade:
    /// 1. SEG_SecurityPolicy.AuthMode (por tenant)
    /// 2. DefaultStrategy (appsettings.json)
    /// </summary>
    private async Task<string> DeterminarAuthModeAsync(Guid? tenantId, CancellationToken ct)
    {
        try
        {
            // Consultar política de segurança do tenant
            SecurityPolicy? securityPolicy = null;

            if (tenantId.HasValue)
            {
                securityPolicy = await _db.Set<SecurityPolicy>()
                    .AsNoTracking()
                    .Where(sp => sp.IdSaaS == tenantId && sp.IsActive)
                    .FirstOrDefaultAsync(ct);
            }

            // Se não encontrou por tenant, buscar política global (IdSaaS = null)
            if (securityPolicy == null)
            {
                securityPolicy = await _db.Set<SecurityPolicy>()
                    .AsNoTracking()
                    .Where(sp => sp.IdSaaS == null && sp.IsActive)
                    .FirstOrDefaultAsync(ct);
            }

            // Se encontrou política e tem AuthMode definido, usar
            if (securityPolicy != null && !string.IsNullOrWhiteSpace(securityPolicy.AuthMode))
            {
                _logger.LogInformation(
                    "✅ AuthMode obtido do banco: '{AuthMode}' (Tenant: {TenantId})",
                    securityPolicy.AuthMode,
                    tenantId?.ToString() ?? "Global");

                return securityPolicy.AuthMode;
            }

            // Fallback: usar configuração padrão do appsettings
            _logger.LogInformation(
                "⚠️ AuthMode não encontrado no banco. Usando DefaultStrategy: '{DefaultStrategy}'",
                _authSettings.DefaultStrategy);

            return _authSettings.DefaultStrategy;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Erro ao determinar AuthMode. Usando DefaultStrategy: '{DefaultStrategy}'",
                _authSettings.DefaultStrategy);

            return _authSettings.DefaultStrategy;
        }
    }

    /// <summary>
    /// ✅ NOVO: Localiza usuário por email ou cdusuario conforme o AuthMode.
    /// - Legacy: busca por cdusuario OU email
    /// - SaaS: busca SOMENTE por email
    /// - ADWin: busca por cdusuario
    /// </summary>
    private async Task<Usuario?> LocalizarUsuarioAsync(
        string loginIdentifier,
        string authMode,
        CancellationToken ct)
    {
        Usuario? usuario = null;

        switch (authMode)
        {
            case "SaaS":
                // SaaS: buscar SOMENTE por email
                _logger.LogDebug("🔍 Buscando usuário por EMAIL (modo SaaS): {Email}", loginIdentifier);
                usuario = await _db.Usuarios
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u => u.Email_Usuario == loginIdentifier, ct);
                break;

            case "Legacy":
                // Legacy: buscar por cdusuario OU email
                _logger.LogDebug("🔍 Buscando usuário por CDUSUARIO ou EMAIL (modo Legacy): {Identifier}", loginIdentifier);
                usuario = await _db.Usuarios
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u =>
                        u.CdUsuario == loginIdentifier ||
                        u.Email_Usuario == loginIdentifier, ct);
                break;

            case "ADWin":
                // ADWin: buscar por cdusuario (deve corresponder ao AD)
                _logger.LogDebug("🔍 Buscando usuário por CDUSUARIO (modo ADWin): {CdUsuario}", loginIdentifier);
                usuario = await _db.Usuarios
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u => u.CdUsuario == loginIdentifier, ct);
                break;

            default:
                _logger.LogWarning("⚠️ AuthMode desconhecido: '{AuthMode}'. Usando busca padrão por cdusuario.", authMode);
                usuario = await _db.Usuarios
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u => u.CdUsuario == loginIdentifier, ct);
                break;
        }

        return usuario;
    }

    // ============================================================================
    // MÉTODOS AUXILIARES - MANTIDOS DO CÓDIGO ORIGINAL
    // ============================================================================

    /// <summary>
    /// Valida a senha do usuário conforme a estratégia de autenticação.
    /// </summary>
    private bool ValidatePassword(Usuario usuario, UserSecurity? userSecurity, string senha, string strategy)
    {
        switch (strategy)
        {
            case "Legacy":
                // Legacy: comparação direta da senha (sem hash)
                if (!string.IsNullOrWhiteSpace(usuario.SenhaUser))
                {
                    // Comparação em tempo constante para reduzir superfície de ataque
                    return ConstantTimeEquals(senha, usuario.SenhaUser);
                }

                return false;

            case "SaaS":
                // SaaS: validação via BCrypt
                if (userSecurity == null || string.IsNullOrWhiteSpace(userSecurity.PasswordHash))
                {
                    return false;
                }

                return BCryptNet.Verify(senha, userSecurity.PasswordHash);

            case "ADWin":
                _logger.LogWarning("Autenticação ADWin ainda não implementada (FASE 3).");
                return false;

            default:
                return false;
        }
    }

    /// <summary>
    /// Comparação de strings em tempo constante (mitigação de timing attacks).
    /// </summary>
    private static bool ConstantTimeEquals(string a, string b)
    {
        if (a == null || b == null)
        {
            return false;
        }

        if (a.Length != b.Length)
        {
            return false;
        }

        var result = 0;
        for (var i = 0; i < a.Length; i++)
        {
            result |= a[i] ^ b[i];
        }

        return result == 0;
    }

    /// <summary>
    /// Busca ou cria UserSecurity para usuário legado (migração automática).
    /// </summary>
    private async Task<UserSecurity> GetOrCreateUserSecurityAsync(Usuario usuario, CancellationToken ct)
    {
        var userSecurity = await _db.Set<UserSecurity>()
            .FirstOrDefaultAsync(us => us.IdUsuario == usuario.Id, ct);

        if (userSecurity == null)
        {
            var passwordHash = !string.IsNullOrWhiteSpace(usuario.PasswordHash)
                ? usuario.PasswordHash
                : BCryptNet.HashPassword(usuario.SenhaUser ?? "ChangeMe@123");

            userSecurity = new UserSecurity(
                usuario.Id,
                usuario.TenantId,
                passwordHash,
                string.Empty);

            userSecurity.ConfirmEmail();

            _db.Set<UserSecurity>().Add(userSecurity);
            await _db.SaveChangesAsync(ct);

            _logger.LogInformation(
                "UserSecurity criado automaticamente para usuário legado: {CdUsuario}",
                usuario.CdUsuario);
        }

        return userSecurity;
    }

    /// <summary>
    /// Atualiza UserSecurity no banco (lockout e tentativas de login).
    /// </summary>
    private async Task UpdateUserSecurityInDatabaseAsync(UserSecurity userSecurity, CancellationToken ct)
    {
        var parameters = new[]
        {
            new SqlParameter("@AccessFailedCount", userSecurity.AccessFailedCount),
            new SqlParameter("@LockoutEnd", userSecurity.LockoutEnd.HasValue ? userSecurity.LockoutEnd.Value : DBNull.Value),
            new SqlParameter("@UpdatedAt", _dateTimeProvider.UtcNow),
            new SqlParameter("@Id", userSecurity.Id),
            new SqlParameter("@ConcurrencyStamp", userSecurity.ConcurrencyStamp)
        };

        await _db.Database.ExecuteSqlRawAsync(
            @"UPDATE dbo.SEG_UserSecurity
              SET AccessFailedCount = @AccessFailedCount,
                  LockoutEnd = @LockoutEnd,
                  UpdatedAt = @UpdatedAt
              WHERE Id = @Id AND ConcurrencyStamp = @ConcurrencyStamp;",
            parameters,
            ct);
    }

    /// <summary>
    /// Registra tentativa de login bem-sucedida no audit log.
    /// </summary>
    private async Task RegisterSuccessfulLoginAsync(
        UserSecurity userSecurity,
        string ipAddress,
        string? userAgent,
        CancellationToken ct)
    {
        try
        {
            var parameters = new[]
            {
                new SqlParameter("@IdUserSecurity", userSecurity.Id),
                new SqlParameter("@IdSaaS", userSecurity.IdSaaS.HasValue ? userSecurity.IdSaaS.Value : DBNull.Value),
                new SqlParameter("@IpAddress", !string.IsNullOrWhiteSpace(ipAddress) ? ipAddress : DBNull.Value),
                new SqlParameter("@UserAgent", !string.IsNullOrWhiteSpace(userAgent) ? userAgent : DBNull.Value),
                new SqlParameter("@LoginAttemptAt", _dateTimeProvider.UtcNow)
            };

            await _db.Database.ExecuteSqlRawAsync(
                @"INSERT INTO [dbo].[SEG_LoginAuditLog] 
                      ([IdUserSecurity], [IdSaaS], [IsSuccess], [IpAddress], [UserAgent], [LoginAttemptAt])
                  VALUES 
                      (@IdUserSecurity, @IdSaaS, 1, @IpAddress, @UserAgent, @LoginAttemptAt);",
                parameters,
                ct);

            _logger.LogInformation("✅ LOGIN: Audit log registrado com sucesso");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "⚠️ AUDIT: Erro ao registrar login no audit log (não crítico)");
        }
    }

    /// <summary>
    /// Registra tentativa de login falhada no audit log.
    /// </summary>
    private async Task RegisterFailedLoginAsync(
        UserSecurity userSecurity,
        string ipAddress,
        string? userAgent,
        string failureReason,
        CancellationToken ct)
    {
        try
        {
            var parameters = new[]
            {
                new SqlParameter("@IdUserSecurity", userSecurity.Id),
                new SqlParameter("@IdSaaS", userSecurity.IdSaaS.HasValue ? userSecurity.IdSaaS.Value : DBNull.Value),
                new SqlParameter("@IpAddress", !string.IsNullOrWhiteSpace(ipAddress) ? ipAddress : DBNull.Value),
                new SqlParameter("@UserAgent", !string.IsNullOrWhiteSpace(userAgent) ? userAgent : DBNull.Value),
                new SqlParameter("@FailureReason", !string.IsNullOrWhiteSpace(failureReason) ? failureReason : DBNull.Value),
                new SqlParameter("@LoginAttemptAt", _dateTimeProvider.UtcNow)
            };

            await _db.Database.ExecuteSqlRawAsync(
                @"INSERT INTO [dbo].[SEG_LoginAuditLog] 
                      ([IdUserSecurity], [IdSaaS], [IsSuccess], [IpAddress], [UserAgent], [FailureReason], [LoginAttemptAt])
                  VALUES 
                      (@IdUserSecurity, @IdSaaS, 0, @IpAddress, @UserAgent, @FailureReason, @LoginAttemptAt);",
                parameters,
                ct);

            _logger.LogInformation("✅ LOGIN: Audit log de falha registrado");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "⚠️ AUDIT: Erro ao registrar falha de login no audit log (não crítico)");
        }
    }

    // ============================================================================
    // OUTROS MÉTODOS (RefreshTokenAsync, LogoutAsync, etc.)
    // Mantidos do código original - não alterados na FASE 1
    // ============================================================================
    // [... resto do código original ...]
}
