// ============================================================================
// BANCOS LIST VIEW MODEL
// ============================================================================
// Arquivo: Models/Bancos/BancosListViewModel.cs
//
// ViewModel para listagem de Bancos.
// Herda de BaseListViewModel e configura propriedades específicas.
//
// ============================================================================

using RhSensoERP.Web.Models.Base;

namespace RhSensoERP.Web.Models.Bancos;

/// <summary>
/// ViewModel para listagem de Bancos.
/// </summary>
public sealed class BancosListViewModel : BaseListViewModel
{
    /// <summary>
    /// Construtor padrão.
    /// Inicializa propriedades específicas de Bancos.
    /// </summary>
    public BancosListViewModel()
    {
        // Informações da página
        PageTitle = "Cadastro de Bancos";
        PageSubtitle = "Gerenciamento de instituições bancárias";
        PageIcon = "fas fa-university";

        // Configuração do controller
        ControllerName = "Bancos";

        // Código da função para controle de permissões
        CdFuncao = "BAN001";

        // Configurações de exportação
        ExportEnabled = true;
        ExportExcel = true;
        ExportPdf = true;
        ExportCsv = true;
        ExportPrint = true;
        ExportFilename = "Bancos";

        // Configurações DataTables
        PageLength = 10;
        LengthMenuOptions = new[] { 10, 25, 50, 100 };
        DefaultOrderColumn = 1; // Ordena por código
        DefaultOrderDirection = "asc";

        // Elementos de UI
        ShowCreateButton = true;
        ShowDeleteMultipleButton = true;
        ShowRefreshButton = true;
        ShowExportButtons = true;
        ShowSelectColumn = true;
        ShowActionsColumn = true;
        ShowSearchBox = true;

        // Mensagens customizadas (opcional)
        EmptyTableMessage = "Nenhum banco cadastrado. Clique em 'Novo' para adicionar.";
    }
}
