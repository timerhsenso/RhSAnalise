// =============================================================================
// GERADOR FULL-STACK v3.0 - MODELS
// Unifica GeradorEntidades + CrudTool Templates
// =============================================================================

namespace GeradorEntidades.Models;

#region Tabela e Colunas (Database Metadata)

/// <summary>
/// Informações de uma tabela do banco.
/// </summary>
public class TabelaInfo
{
    public string Schema { get; set; } = "dbo";
    public string NomeTabela { get; set; } = string.Empty;
    public string NomeLimpo => LimparNome(NomeTabela);
    public string NomePascalCase => ToPascalCase(NomeLimpo);
    public string NomePlural => Pluralizar(NomePascalCase);
    public string NomePluralLower => NomePlural.ToLowerInvariant();
    public string NomeLower => NomePascalCase.ToLowerInvariant();
    public string Descricao { get; set; } = string.Empty;
    public List<ColunaInfo> Colunas { get; set; } = [];
    public List<ForeignKeyInfo> ForeignKeys { get; set; } = [];
    public List<IndexInfo> Indices { get; set; } = [];

    /// <summary>
    /// Coluna PK (ou primeira coluna como fallback).
    /// </summary>
    public ColunaInfo? PrimaryKey => Colunas.FirstOrDefault(c => c.IsPrimaryKey)
                                     ?? Colunas.FirstOrDefault();

    /// <summary>
    /// Se tem Primary Key definida.
    /// </summary>
    public bool HasPrimaryKey => Colunas.Any(c => c.IsPrimaryKey);

    /// <summary>
    /// Se tem PK composta (mais de uma coluna).
    /// </summary>
    public bool HasCompositePrimaryKey => Colunas.Count(c => c.IsPrimaryKey) > 1;

    /// <summary>
    /// Colunas que fazem parte da PK.
    /// </summary>
    public List<ColunaInfo> PrimaryKeyColumns => Colunas.Where(c => c.IsPrimaryKey).ToList();

    /// <summary>
    /// Se tem FKs compostas.
    /// </summary>
    public bool HasCompositeForeignKeys => ForeignKeys.Any(fk => fk.IsParteDeFkComposta);

    /// <summary>
    /// Remove prefixos comuns de tabelas legadas.
    /// </summary>
    private static string LimparNome(string nome)
    {
        var prefixes = new[] { "tbl_", "tb_", "tab_", "t_", "tbl", "tb" };
        var resultado = nome;

        foreach (var prefix in prefixes)
        {
            if (resultado.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
                && resultado.Length > prefix.Length + 2)
            {
                resultado = resultado[prefix.Length..];
                break;
            }
        }

        return resultado;
    }

    /// <summary>
    /// Converte para PascalCase.
    /// </summary>
    public static string ToPascalCase(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        // Se já está em PascalCase ou camelCase, apenas garante primeira maiúscula
        if (input.Any(char.IsUpper))
        {
            return char.ToUpper(input[0]) + input[1..];
        }

        // snake_case para PascalCase
        var parts = input.Split('_', StringSplitOptions.RemoveEmptyEntries);
        return string.Concat(parts.Select(p =>
            char.ToUpper(p[0]) + p[1..].ToLower()));
    }

    /// <summary>
    /// Pluraliza o nome (português simplificado).
    /// </summary>
    private static string Pluralizar(string nome)
    {
        if (string.IsNullOrEmpty(nome)) return nome;

        if (nome.EndsWith("ao", StringComparison.OrdinalIgnoreCase))
            return nome[..^2] + "oes";
        if (nome.EndsWith("r", StringComparison.OrdinalIgnoreCase) ||
            nome.EndsWith("z", StringComparison.OrdinalIgnoreCase) ||
            nome.EndsWith("s", StringComparison.OrdinalIgnoreCase))
            return nome + "es";
        if (nome.EndsWith("l", StringComparison.OrdinalIgnoreCase))
            return nome[..^1] + "is";
        if (nome.EndsWith("m", StringComparison.OrdinalIgnoreCase))
            return nome[..^1] + "ns";

        return nome + "s";
    }
}

/// <summary>
/// Informações de uma coluna.
/// </summary>
public class ColunaInfo
{
    public string Nome { get; set; } = string.Empty;
    public string NomePascalCase => ToPascalCase(Nome);
    public string NomeCamelCase => ToCamelCase(Nome);
    public string Tipo { get; set; } = string.Empty;
    public int? Tamanho { get; set; }
    public int? Precisao { get; set; }
    public int? Escala { get; set; }
    public bool IsNullable { get; set; }
    public bool IsPrimaryKey { get; set; }
    public bool IsIdentity { get; set; }
    public bool IsComputed { get; set; }
    public string? DefaultValue { get; set; }
    public string? Descricao { get; set; }
    public int OrdinalPosition { get; set; }

    /// <summary>
    /// FK relacionada (se houver).
    /// </summary>
    public ForeignKeyInfo? ForeignKey { get; set; }

    /// <summary>
    /// Tipo C# correspondente.
    /// </summary>
    public string TipoCSharp => GetCSharpType();

    /// <summary>
    /// Tipo C# simples (sem nullable marker).
    /// </summary>
    public string TipoCSharpSimples => GetCSharpTypeSimple();

    /// <summary>
    /// Tipo JSON correspondente.
    /// </summary>
    public string TipoJson => GetJsonType();

    /// <summary>
    /// Se é tipo texto.
    /// </summary>
    public bool IsTexto => Tipo.ToLower() is "varchar" or "nvarchar" or "char" or "nchar" or "text" or "ntext";

    /// <summary>
    /// Se é tipo numérico.
    /// </summary>
    public bool IsNumerico => Tipo.ToLower() is "int" or "bigint" or "smallint" or "tinyint"
                              or "decimal" or "numeric" or "money" or "float" or "real";

    /// <summary>
    /// Se é tipo inteiro.
    /// </summary>
    public bool IsInt => Tipo.ToLower() is "int" or "smallint" or "tinyint";

    /// <summary>
    /// Se é tipo long.
    /// </summary>
    public bool IsLong => Tipo.ToLower() is "bigint";

    /// <summary>
    /// Se é tipo decimal.
    /// </summary>
    public bool IsDecimal => Tipo.ToLower() is "decimal" or "numeric" or "money" or "smallmoney" or "float" or "real";

    /// <summary>
    /// Se é tipo boolean.
    /// </summary>
    public bool IsBool => Tipo.ToLower() is "bit";

    /// <summary>
    /// Se é tipo data.
    /// </summary>
    public bool IsData => Tipo.ToLower() is "datetime" or "datetime2" or "date" or "smalldatetime" or "time";

    /// <summary>
    /// Se é tipo DateTime.
    /// </summary>
    public bool IsDateTime => Tipo.ToLower() is "datetime" or "datetime2" or "smalldatetime";

    /// <summary>
    /// Se é tipo Guid.
    /// </summary>
    public bool IsGuid => Tipo.ToLower() == "uniqueidentifier";

    /// <summary>
    /// Se é tipo string (para C#).
    /// </summary>
    public bool IsString => IsTexto;

    /// <summary>
    /// Se é tipo binário (byte[]).
    /// </summary>
    public bool IsBinary => Tipo.ToLower() is "binary" or "varbinary" or "image" or "timestamp" or "rowversion";

    // Prefixos conhecidos para melhor conversão PascalCase
    private static readonly string[] PrefixosConhecidos = new[]
    {
        "cd", "dc", "dt", "nr", "nm", "fl", "vl", "qt", "sg", "no", "id", "tp", "st", "ds", "tx", "pc", "hr"
    };

    private static string ToPascalCase(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        // Se tem underscore, processa como snake_case
        if (input.Contains('_'))
        {
            var parts = input.Split('_', StringSplitOptions.RemoveEmptyEntries);
            var sb = new System.Text.StringBuilder();
            foreach (var part in parts)
            {
                sb.Append(ProcessPascalCasePart(part.ToLowerInvariant()));
            }
            return sb.ToString();
        }

        // Se já tem letras maiúsculas misturadas, provavelmente já está em PascalCase
        if (HasMixedCase(input))
        {
            return char.ToUpper(input[0]) + input[1..];
        }

        // Processa como string contínua
        return ProcessPascalCasePart(input.ToLowerInvariant());
    }

    private static bool HasMixedCase(string input)
    {
        bool hasUpper = false;
        bool hasLower = false;
        foreach (var c in input)
        {
            if (char.IsUpper(c)) hasUpper = true;
            if (char.IsLower(c)) hasLower = true;
            if (hasUpper && hasLower) return true;
        }
        return false;
    }

    private static string ProcessPascalCasePart(string part)
    {
        if (string.IsNullOrEmpty(part)) return part;

        var result = new System.Text.StringBuilder();
        var i = 0;

        while (i < part.Length)
        {
            var prefixoEncontrado = false;
            foreach (var prefixo in PrefixosConhecidos)
            {
                if (i + prefixo.Length <= part.Length &&
                    part.Substring(i, prefixo.Length) == prefixo)
                {
                    result.Append(char.ToUpper(prefixo[0]));
                    result.Append(prefixo[1..]);
                    i += prefixo.Length;
                    prefixoEncontrado = true;
                    break;
                }
            }

            if (!prefixoEncontrado)
            {
                result.Append(result.Length == 0 ? char.ToUpper(part[i]) : part[i]);
                i++;
            }
        }

        return result.ToString();
    }

    private static string ToCamelCase(string input)
    {
        var pascal = ToPascalCase(input);
        if (string.IsNullOrEmpty(pascal)) return pascal;
        return char.ToLower(pascal[0]) + pascal[1..];
    }

    private string GetCSharpType()
    {
        var sqlType = Tipo.ToLowerInvariant();

        string baseType = sqlType switch
        {
            "varchar" or "nvarchar" or "char" or "nchar" or "text" or "ntext" => "string",
            "int" => "int",
            "smallint" => "short",
            "tinyint" => "byte",
            "bigint" => "long",
            "bit" => "bool",
            "decimal" or "numeric" or "money" or "smallmoney" => "decimal",
            "float" => "double",
            "real" => "float",
            "datetime" or "smalldatetime" or "datetime2" => "DateTime",
            "date" => "DateOnly",
            "time" => "TimeOnly",
            "datetimeoffset" => "DateTimeOffset",
            "uniqueidentifier" => "Guid",
            "varbinary" or "binary" or "image" => "byte[]",
            _ => "string"
        };

        if (baseType == "string" || baseType == "byte[]")
            return baseType;

        return IsNullable ? $"{baseType}?" : baseType;
    }

    private string GetCSharpTypeSimple()
    {
        var sqlType = Tipo.ToLowerInvariant();

        return sqlType switch
        {
            "varchar" or "nvarchar" or "char" or "nchar" or "text" or "ntext" => "string",
            "int" => "int",
            "smallint" => "short",
            "tinyint" => "byte",
            "bigint" => "long",
            "bit" => "bool",
            "decimal" or "numeric" or "money" or "smallmoney" => "decimal",
            "float" => "double",
            "real" => "float",
            "datetime" or "smalldatetime" or "datetime2" => "DateTime",
            "date" => "DateOnly",
            "time" => "TimeOnly",
            "datetimeoffset" => "DateTimeOffset",
            "uniqueidentifier" => "Guid",
            "varbinary" or "binary" or "image" => "byte[]",
            _ => "string"
        };
    }

    private string GetJsonType()
    {
        var sqlType = Tipo.ToLowerInvariant();

        return sqlType switch
        {
            "varchar" or "nvarchar" or "char" or "nchar" or "text" or "ntext" => "string",
            "int" or "smallint" or "tinyint" or "bigint" => "number",
            "decimal" or "numeric" or "money" or "smallmoney" or "float" or "real" => "number",
            "bit" => "boolean",
            "datetime" or "smalldatetime" or "datetime2" or "date" => "date",
            "time" => "time",
            "uniqueidentifier" => "guid",
            _ => "string"
        };
    }
}

/// <summary>
/// Informações de Foreign Key - com Navigation Properties.
/// </summary>
public class ForeignKeyInfo
{
    public string Nome { get; set; } = string.Empty;
    public string ColunaOrigem { get; set; } = string.Empty;
    public string TabelaDestino { get; set; } = string.Empty;
    public string ColunaDestino { get; set; } = string.Empty;

    /// <summary>
    /// Se esta FK faz parte de uma FK composta (mais de uma coluna).
    /// </summary>
    public bool IsParteDeFkComposta { get; set; }

    /// <summary>
    /// Lista de todas as colunas desta FK (para FKs compostas).
    /// </summary>
    public List<string> TodasColunas { get; set; } = [];

    /// <summary>
    /// Nome da entidade destino em PascalCase.
    /// </summary>
    public string EntidadeDestino => TabelaInfo.ToPascalCase(TabelaDestino);

    /// <summary>
    /// Nome sugerido para a propriedade de navegação.
    /// </summary>
    public string NavigationPropertyName => GerarNavigationPropertyName();

    /// <summary>
    /// Coluna de display provável na tabela destino.
    /// </summary>
    public string? ColunaDisplay { get; set; }

    /// <summary>
    /// Se a FK é por Guid.
    /// </summary>
    public bool IsFkByGuid => ColunaOrigem.StartsWith("id", StringComparison.OrdinalIgnoreCase)
                              && !ColunaOrigem.Equals("id", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Se a FK é por código legado.
    /// </summary>
    public bool IsFkByCodigo => ColunaOrigem.StartsWith("cd", StringComparison.OrdinalIgnoreCase)
                                || ColunaOrigem.StartsWith("no", StringComparison.OrdinalIgnoreCase)
                                || ColunaOrigem.StartsWith("sg", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Chave única para identificar FKs duplicadas.
    /// </summary>
    public string ChaveUnica => $"{ColunaOrigem.ToLower()}_{TabelaDestino.ToLower()}";

    private string GerarNavigationPropertyName()
    {
        var coluna = ColunaOrigem.ToLower();

        string nomeLimpo;

        if (coluna.StartsWith("id") && coluna.Length > 2)
            nomeLimpo = coluna[2..];
        else if (coluna.StartsWith("cd") && coluna.Length > 2)
            nomeLimpo = coluna[2..];
        else if (coluna.StartsWith("fk") && coluna.Length > 2)
            nomeLimpo = coluna[2..];
        else
            nomeLimpo = coluna;

        return TabelaInfo.ToPascalCase(nomeLimpo);
    }
}

/// <summary>
/// Informações de índice.
/// </summary>
public class IndexInfo
{
    public string Nome { get; set; } = string.Empty;
    public bool IsUnique { get; set; }
    public List<string> Colunas { get; set; } = [];
}

#endregion

#region Request/Response de Geração

/// <summary>
/// Request de geração FULL-STACK com todas as opções.
/// </summary>
public class FullStackRequest
{
    // =========================================================================
    // IDENTIFICAÇÃO
    // =========================================================================
    public string NomeTabela { get; set; } = string.Empty;
    public string CdFuncao { get; set; } = string.Empty;
    public string CdSistema { get; set; } = "RHU";
    public string DisplayName { get; set; } = string.Empty;
    public string Descricao { get; set; } = string.Empty;

    // =========================================================================
    // MENU E NAVEGAÇÃO
    // =========================================================================
    public string Modulo { get; set; } = "GestaoDePessoas";
    public string ModuloRota { get; set; } = "gestaodepessoas";
    public string Icone { get; set; } = "fas fa-table";
    public int MenuOrder { get; set; } = 10;
    public bool GerarMenuItem { get; set; } = true;

    // =========================================================================
    // OPÇÕES DE GERAÇÃO - BACKEND
    // =========================================================================
    public bool GerarEntidade { get; set; } = true;
    public bool GerarApiController { get; set; } = false;
    public bool GerarNavigation { get; set; } = true;
    public bool ApenasNavigationPorGuid { get; set; } = false;
    public bool IsLegacyTable { get; set; } = true;

    // =========================================================================
    // OPÇÕES DE GERAÇÃO - FRONTEND
    // =========================================================================
    public bool GerarWebController { get; set; } = true;
    public bool GerarWebModels { get; set; } = true;
    public bool GerarWebServices { get; set; } = true;
    public bool GerarView { get; set; } = true;
    public bool GerarJavaScript { get; set; } = true;

    // =========================================================================
    // CONFIGURAÇÃO DE COLUNAS
    // =========================================================================
    public List<ColumnListConfig> ColunasListagem { get; set; } = [];
    public List<ColumnFormConfig> ColunasFormulario { get; set; } = [];
    public List<FkNavigationConfig> ConfiguracoesFk { get; set; } = [];

    // =========================================================================
    // CHAVE PRIMÁRIA DEFINIDA MANUALMENTE (para tabelas sem PK no banco)
    // =========================================================================
    public List<PkColumnConfig> ColunasPkDefinidas { get; set; } = [];
}

/// <summary>
/// Configuração de coluna definida como PK pelo usuário.
/// </summary>
public class PkColumnConfig
{
    public string Nome { get; set; } = string.Empty;
    public string NomePascalCase { get; set; } = string.Empty;
}

/// <summary>
/// Configuração de coluna para listagem (DataTable).
/// </summary>
public class ColumnListConfig
{
    public string Nome { get; set; } = string.Empty;
    public bool Visible { get; set; } = true;
    public int Order { get; set; } = 0;
    public string? Title { get; set; }
    public string Format { get; set; } = "text";
    public string? Width { get; set; }
    public string Align { get; set; } = "left";
    public bool Sortable { get; set; } = true;
}

/// <summary>
/// Configuração de coluna para formulário.
/// </summary>
public class ColumnFormConfig
{
    public string Nome { get; set; } = string.Empty;
    public bool Visible { get; set; } = true;
    public int Order { get; set; } = 0;
    public string? Label { get; set; }
    public string InputType { get; set; } = "text";
    public int ColSize { get; set; } = 6;
    public bool Required { get; set; } = false;
    public bool Disabled { get; set; } = false;
    public string? Placeholder { get; set; }
    public string? HelpText { get; set; }
    public string? Mask { get; set; }
    public int? Rows { get; set; }
}

/// <summary>
/// Configuração de FK/Navegação.
/// </summary>
public class FkNavigationConfig
{
    public string ColunaOrigem { get; set; } = string.Empty;
    public string TabelaDestino { get; set; } = string.Empty;
    public string NavigationName { get; set; } = string.Empty;
    public string DisplayColumn { get; set; } = string.Empty;
    public bool Ignorar { get; set; } = false;
}

/// <summary>
/// Resultado da geração FULL-STACK.
/// </summary>
public class FullStackResult
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public string NomeTabela { get; set; } = string.Empty;
    public string NomeEntidade { get; set; } = string.Empty;

    // Arquivos gerados
    public GeneratedFile? Entidade { get; set; }
    public GeneratedFile? WebController { get; set; }
    public GeneratedFile? Dto { get; set; }
    public GeneratedFile? CreateRequest { get; set; }
    public GeneratedFile? UpdateRequest { get; set; }
    public GeneratedFile? ListViewModel { get; set; }
    public GeneratedFile? ServiceInterface { get; set; }
    public GeneratedFile? ServiceImplementation { get; set; }
    public GeneratedFile? View { get; set; }
    public GeneratedFile? JavaScript { get; set; }

    // Metadados
    public List<string> NavigationsGeradas { get; set; } = [];
    public List<string> Warnings { get; set; } = [];

    /// <summary>
    /// Todos os arquivos gerados.
    /// </summary>
    public IEnumerable<GeneratedFile> AllFiles =>
        new[] { Entidade, WebController, Dto, CreateRequest, UpdateRequest,
                ListViewModel, ServiceInterface, ServiceImplementation, View, JavaScript }
            .Where(f => f != null)!;
}

/// <summary>
/// Arquivo gerado.
/// </summary>
public class GeneratedFile
{
    public string FileName { get; set; } = string.Empty;
    public string RelativePath { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public string FileType { get; set; } = string.Empty;
}

#endregion

#region EntityConfig (Compatível com Templates)

/// <summary>
/// Configuração de entidade para templates.
/// Converte de TabelaInfo + FullStackRequest para formato usado pelos templates.
/// </summary>
public class EntityConfig
{
    public string Name { get; set; } = string.Empty;
    public string NameLower => Name.ToLowerInvariant();
    public string PluralName { get; set; } = string.Empty;
    public string PluralNameLower => PluralName.ToLowerInvariant();
    public string DisplayName { get; set; } = string.Empty;
    public string TableName { get; set; } = string.Empty;
    public string CdFuncao { get; set; } = string.Empty;
    public string CdSistema { get; set; } = "RHU";
    public string Module { get; set; } = "GestaoDePessoas";
    public string ModuleRoute { get; set; } = "gestaodepessoas";
    public string ModuleRouteLower => ModuleRoute.ToLowerInvariant();
    public string? BackendNamespace { get; set; }

    // PK Info
    public PropertyConfig? PrimaryKey { get; set; }
    public string PkType => PrimaryKey?.CSharpType ?? "Guid";
    public string PkTypeSimple => PrimaryKey?.CSharpTypeSimple ?? "Guid";

    // Propriedades
    public List<PropertyConfig> Properties { get; set; } = [];

    /// <summary>
    /// Cria EntityConfig a partir de TabelaInfo e FullStackRequest.
    /// </summary>
    public static EntityConfig FromTabela(TabelaInfo tabela, FullStackRequest request)
    {
        // Determinar quais colunas são PK (do banco OU definidas pelo usuário)
        var pkColumnsDefinidas = request.ColunasPkDefinidas
            .Select(p => p.Nome.ToLowerInvariant())
            .ToHashSet();

        var config = new EntityConfig
        {
            Name = tabela.NomePascalCase,
            PluralName = tabela.NomePlural,
            DisplayName = !string.IsNullOrWhiteSpace(request.DisplayName)
                ? request.DisplayName
                : FormatDisplayName(tabela.NomePascalCase),
            TableName = tabela.NomeTabela.ToLower(),
            CdFuncao = request.CdFuncao,
            CdSistema = request.CdSistema,
            Module = request.Modulo,
            ModuleRoute = request.ModuloRota
        };

        // Mapear colunas para propriedades
        var order = 0;
        foreach (var coluna in tabela.Colunas)
        {
            var listConfig = request.ColunasListagem
                .FirstOrDefault(c => c.Nome.Equals(coluna.Nome, StringComparison.OrdinalIgnoreCase));

            var formConfig = request.ColunasFormulario
                .FirstOrDefault(c => c.Nome.Equals(coluna.Nome, StringComparison.OrdinalIgnoreCase));

            // Verificar se esta coluna foi definida como PK pelo usuário
            var isPkDefinida = pkColumnsDefinidas.Contains(coluna.Nome.ToLowerInvariant());
            var isPrimaryKey = coluna.IsPrimaryKey || isPkDefinida;

            var prop = new PropertyConfig
            {
                Name = coluna.NomePascalCase,
                ColumnName = coluna.Nome,
                CSharpType = coluna.TipoCSharp,
                CSharpTypeSimple = coluna.TipoCSharpSimples,
                SqlType = coluna.Tipo,
                DisplayName = listConfig?.Title ?? formConfig?.Label ?? FormatDisplayName(coluna.NomePascalCase),
                IsPrimaryKey = isPrimaryKey,
                IsPrimaryKeyDefinedByUser = isPkDefinida,
                IsIdentity = coluna.IsIdentity,
                IsNullable = coluna.IsNullable,
                IsReadOnly = coluna.IsComputed || coluna.IsIdentity,
                Required = !coluna.IsNullable && !isPrimaryKey,
                MaxLength = coluna.Tamanho,
                IsGuid = coluna.IsGuid,
                IsString = coluna.IsString,
                IsInt = coluna.IsInt,
                IsLong = coluna.IsLong,
                IsDecimal = coluna.IsDecimal,
                IsBool = coluna.IsBool,
                IsDateTime = coluna.IsDateTime,
                HasForeignKey = coluna.ForeignKey != null,
                ForeignKeyTable = coluna.ForeignKey?.TabelaDestino,
                ForeignKeyColumn = coluna.ForeignKey?.ColunaDestino
            };

            // Configuração de listagem
            if (listConfig != null && listConfig.Visible)
            {
                prop.List = new ListConfig
                {
                    Show = true,
                    Order = listConfig.Order,
                    Title = listConfig.Title,
                    Format = listConfig.Format,
                    Width = listConfig.Width,
                    Align = listConfig.Align,
                    Sortable = listConfig.Sortable
                };
            }
            else if (listConfig == null && !isPrimaryKey && !coluna.IsGuid)
            {
                // Default: mostrar colunas simples
                prop.List = new ListConfig
                {
                    Show = true,
                    Order = order++,
                    Format = GetDefaultFormat(coluna),
                    Sortable = true
                };
            }

            // Configuração de formulário
            if (formConfig != null && formConfig.Visible)
            {
                prop.Form = new FormConfig
                {
                    Show = true,
                    Order = formConfig.Order,
                    InputType = formConfig.InputType,
                    ColSize = formConfig.ColSize,
                    Placeholder = formConfig.Placeholder,
                    HelpText = formConfig.HelpText,
                    Disabled = formConfig.Disabled,
                    Rows = formConfig.Rows ?? 3
                };
            }
            // PKs string/char que não são Identity precisam aparecer no form (usuário digita)
            else if (formConfig == null && isPrimaryKey && !coluna.IsIdentity && !coluna.IsGuid && coluna.IsTexto)
            {
                prop.Form = new FormConfig
                {
                    Show = true,
                    ShowOnCreate = true,  // Mostra ao criar (usuário digita o código)
                    ShowOnEdit = false,   // Não mostra ao editar (PK não muda)
                    Order = 0,            // Primeiro campo
                    InputType = "text",
                    ColSize = coluna.Tamanho <= 10 ? 4 : 6,
                    Disabled = false
                };
            }
            else if (formConfig == null && !isPrimaryKey && !coluna.IsComputed)
            {
                // Default: mostrar campos editáveis
                prop.Form = new FormConfig
                {
                    Show = true,
                    Order = order,
                    InputType = GetDefaultInputType(coluna),
                    ColSize = GetDefaultColSize(coluna)
                };
            }

            config.Properties.Add(prop);

            // Definir PrimaryKey (primeira encontrada, ou primeira definida pelo usuário)
            if (isPrimaryKey && config.PrimaryKey == null)
            {
                config.PrimaryKey = prop;
            }
        }

        return config;
    }

    private static string FormatDisplayName(string name)
    {
        if (string.IsNullOrEmpty(name)) return name;

        var sb = new System.Text.StringBuilder();

        for (int i = 0; i < name.Length; i++)
        {
            var c = name[i];

            if (i > 0 && char.IsUpper(c) && !char.IsUpper(name[i - 1]))
            {
                sb.Append(' ');
            }

            sb.Append(c);
        }

        var resultado = sb.ToString()
            .Replace("Cd ", "Código ")
            .Replace("Dc ", "Descrição ")
            .Replace("Dt ", "Data ")
            .Replace("Nr ", "Número ")
            .Replace("Nm ", "Nome ")
            .Replace("Fl ", "Flag ")
            .Replace("Vl ", "Valor ")
            .Replace("Qt ", "Quantidade ")
            .Replace("Sg ", "Sigla ")
            .Replace("No ", "Número ")
            .Replace("Tp ", "Tipo ")
            .Replace("St ", "Status ")
            .Replace("Ds ", "Descrição ")
            .Replace("Tx ", "Taxa ")
            .Replace("Pc ", "Percentual ")
            .Replace("Hr ", "Hora ")
            .Replace("Id ", "")
            .Trim();

        return resultado;
    }

    private static string GetDefaultFormat(ColunaInfo coluna)
    {
        if (coluna.IsData) return "date";
        if (coluna.Tipo.ToLower() is "decimal" or "money" or "numeric") return "currency";
        if (coluna.IsBool) return "boolean";
        return "text";
    }

    private static string GetDefaultInputType(ColunaInfo coluna)
    {
        if (coluna.IsData) return coluna.Tipo.ToLower() == "date" ? "date" : "datetime-local";
        if (coluna.IsBool) return "checkbox";
        if (coluna.IsNumerico) return "number";
        if (coluna.IsTexto && coluna.Tamanho > 255) return "textarea";
        if (coluna.ForeignKey != null) return "select";
        return "text";
    }

    private static int GetDefaultColSize(ColunaInfo coluna)
    {
        if (coluna.IsBool) return 2;
        if (coluna.IsData) return 4;
        if (coluna.IsNumerico) return 3;
        if (coluna.Tamanho.HasValue && coluna.Tamanho < 20) return 3;
        if (coluna.Tamanho.HasValue && coluna.Tamanho > 255) return 12;
        return 6;
    }
}

/// <summary>
/// Configuração de propriedade.
/// </summary>
public class PropertyConfig
{
    public string Name { get; set; } = string.Empty;
    public string ColumnName { get; set; } = string.Empty;
    public string CSharpType { get; set; } = string.Empty;
    public string CSharpTypeSimple { get; set; } = string.Empty;
    public string SqlType { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;

    public bool IsPrimaryKey { get; set; }
    public bool IsPrimaryKeyDefinedByUser { get; set; } // PK definida manualmente pelo usuário (não existe no banco)
    public bool IsIdentity { get; set; }
    public bool IsNullable { get; set; }
    public bool IsReadOnly { get; set; }
    public bool Required { get; set; }
    public int? MaxLength { get; set; }
    public int? MinLength { get; set; }

    public bool IsGuid { get; set; }
    public bool IsString { get; set; }
    public bool IsInt { get; set; }
    public bool IsLong { get; set; }
    public bool IsDecimal { get; set; }
    public bool IsBool { get; set; }
    public bool IsDateTime { get; set; }

    public bool HasForeignKey { get; set; }
    public string? ForeignKeyTable { get; set; }
    public string? ForeignKeyColumn { get; set; }

    public ListConfig? List { get; set; }
    public FormConfig? Form { get; set; }

    /// <summary>
    /// Gera declaração da propriedade C#.
    /// </summary>
    public string GetPropertyDeclaration()
    {
        var defaultValue = CSharpType switch
        {
            "string" => " = string.Empty;",
            _ when CSharpType.EndsWith("?") => "",
            _ => ""
        };

        return $"public {CSharpType} {Name} {{ get; set; }}{defaultValue}";
    }
}

/// <summary>
/// Configuração de exibição na listagem.
/// </summary>
public class ListConfig
{
    public bool Show { get; set; } = true;
    public int Order { get; set; }
    public string? Title { get; set; }
    public string Format { get; set; } = "text";
    public string? Width { get; set; }
    public string Align { get; set; } = "left";
    public bool Sortable { get; set; } = true;
}

/// <summary>
/// Configuração de exibição no formulário.
/// </summary>
public class FormConfig
{
    public bool Show { get; set; } = true;
    public bool ShowOnCreate { get; set; } = true;
    public bool ShowOnEdit { get; set; } = true;
    public int Order { get; set; }
    public string InputType { get; set; } = "text";
    public int ColSize { get; set; } = 6;
    public string? Placeholder { get; set; }
    public string? HelpText { get; set; }
    public bool Disabled { get; set; }
    public int Rows { get; set; } = 3;
}

#endregion

#region Módulos e Funções

/// <summary>
/// Configuração de módulos disponíveis.
/// </summary>
public class ModuloConfig
{
    public string Nome { get; set; } = string.Empty;
    public string Rota { get; set; } = string.Empty;
    public string CdSistema { get; set; } = string.Empty;
    public string Namespace { get; set; } = string.Empty;
    public string Icone { get; set; } = string.Empty;

    public static List<ModuloConfig> GetModulos() =>
    [
        new() { Nome = "Identity", Rota = "identity", CdSistema = "SEG",
                Namespace = "RhSensoERP.Modules.Identity", Icone = "fas fa-shield-alt" },
        new() { Nome = "GestaoDePessoas", Rota = "gestaodepessoas", CdSistema = "RHU",
                Namespace = "RhSensoERP.Modules.GestaoDePessoas", Icone = "fas fa-users" },
        new() { Nome = "ControleDePonto", Rota = "controledeponto", CdSistema = "CPO",
                Namespace = "RhSensoERP.Modules.ControleDePonto", Icone = "fas fa-clock" },
        new() { Nome = "Treinamento", Rota = "treinamento", CdSistema = "TRE",
                Namespace = "RhSensoERP.Modules.Treinamento", Icone = "fas fa-graduation-cap" },
        new() { Nome = "SaudeOcupacional", Rota = "saudeocupacional", CdSistema = "MSO",
                Namespace = "RhSensoERP.Modules.SaudeOcupacional", Icone = "fas fa-heartbeat" },
        new() { Nome = "Avaliacao", Rota = "avaliacao", CdSistema = "AVA",
                Namespace = "RhSensoERP.Modules.Avaliacao", Icone = "fas fa-chart-line" },
    ];
}

/// <summary>
/// Informações de função do sistema (tabela fucn1).
/// </summary>
public class FuncaoInfo
{
    public string CdFuncao { get; set; } = string.Empty;
    public string DcFuncao { get; set; } = string.Empty;
    public string CdSistema { get; set; } = string.Empty;
}

/// <summary>
/// Informações de coluna de display para tabelas relacionadas.
/// </summary>
public class TabelaDisplayInfo
{
    public string NomeTabela { get; set; } = string.Empty;
    public string? ColunaDisplay { get; set; }
    public string? ColunaDescricao { get; set; }
    public string? ColunaCodigo { get; set; }
}

#endregion

#region Request Legado (compatibilidade)

/// <summary>
/// Request de geração legado (compatibilidade com versão anterior).
/// </summary>
public class GeracaoRequest
{
    public string NomeTabela { get; set; } = string.Empty;
    public string CdFuncao { get; set; } = string.Empty;
    public string CdSistema { get; set; } = "RHU";
    public string Modulo { get; set; } = "GestaoDePessoas";
    public string ModuloRota { get; set; } = "gestaodepessoas";
    public string DisplayName { get; set; } = string.Empty;
    public string Icone { get; set; } = "fas fa-table";
    public int MenuOrder { get; set; } = 10;
    public bool GerarApiController { get; set; } = false;
    public bool GerarWebController { get; set; } = true;
    public bool GerarMenuItem { get; set; } = true;
    public bool IsLegacyTable { get; set; } = true;
    public bool GerarNavigation { get; set; } = true;
    public bool ApenasNavigationPorGuid { get; set; } = false;
    public List<string> ColunasListagem { get; set; } = [];
    public List<string> ColunasFormulario { get; set; } = [];

    /// <summary>
    /// Converte para FullStackRequest.
    /// </summary>
    public FullStackRequest ToFullStackRequest()
    {
        return new FullStackRequest
        {
            NomeTabela = NomeTabela,
            CdFuncao = CdFuncao,
            CdSistema = CdSistema,
            Modulo = Modulo,
            ModuloRota = ModuloRota,
            DisplayName = DisplayName,
            Icone = Icone,
            MenuOrder = MenuOrder,
            GerarApiController = GerarApiController,
            GerarWebController = GerarWebController,
            GerarMenuItem = GerarMenuItem,
            IsLegacyTable = IsLegacyTable,
            GerarNavigation = GerarNavigation,
            ApenasNavigationPorGuid = ApenasNavigationPorGuid
        };
    }
}

/// <summary>
/// Resultado da geração legado (compatibilidade).
/// </summary>
public class GeracaoResult
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public string NomeTabela { get; set; } = string.Empty;
    public string NomeEntidade { get; set; } = string.Empty;
    public string CodigoEntidade { get; set; } = string.Empty;
    public string JsonConfig { get; set; } = string.Empty;
    public string NomeArquivoEntidade => $"{NomeEntidade}.cs";
    public string NomeArquivoJson => $"crud-config-{NomeEntidade}.json";
    public List<string> NavigationsGeradas { get; set; } = [];
}

#endregion