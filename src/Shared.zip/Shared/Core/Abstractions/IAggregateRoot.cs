// Copyright (c) RhSenso. Todos os direitos reservados.

namespace RhSensoERP.Shared.Core.Abstractions;

/// <summary>Marcador para raízes de agregados (DDD).</summary>
public interface IAggregateRoot
{
}
