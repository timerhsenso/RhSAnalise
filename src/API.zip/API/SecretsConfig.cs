﻿// src/API/SecretsConfig.cs
namespace RhSensoERP.API;

/// <summary>
/// Classe marcadora para User Secrets
/// </summary>
public class SecretsConfig
{
    // Esta classe existe apenas para servir como âncora para o User Secrets
    // Não adicione propriedades aqui - use a configuração do .NET
}