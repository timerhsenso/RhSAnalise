// =============================================================================
// RHSENSOERP WEB - SISTEMAS LIST VIEW MODEL (COM PERMISSÕES)
// =============================================================================
using RhSensoERP.Web.Models.Base;

namespace RhSensoERP.Web.Models.Sistemas;

/// <summary>
/// ViewModel para a listagem de Sistemas com controle de permissões.
/// </summary>
public class SistemasListViewModel : BaseCrudListViewModel
{
    // =========================================================================
    // PROPRIEDADES HERDADAS DE BaseCrudListViewModel:
    // - PageTitle
    // - UserPermissions (string com as ações: "IAEC")
    // =========================================================================

    // =========================================================================
    // PERMISSÕES ESPECÍFICAS (Flags Booleanas)
    // =========================================================================
    
    /// <summary>
    /// Indica se o usuário pode INCLUIR (I) novos registros.
    /// </summary>
    public bool CanCreate { get; set; }

    /// <summary>
    /// Indica se o usuário pode ALTERAR (A) registros existentes.
    /// </summary>
    public bool CanEdit { get; set; }

    /// <summary>
    /// Indica se o usuário pode EXCLUIR (E) registros.
    /// </summary>
    public bool CanDelete { get; set; }

    /// <summary>
    /// Indica se o usuário pode CONSULTAR (C) registros.
    /// </summary>
    public bool CanView { get; set; }

    // =========================================================================
    // CONSTRUTOR
    // =========================================================================

    public SistemasListViewModel()
    {
        PageTitle = "Cadastro de Sistemas";
        
        // Valores padrão (serão sobrescritos pelo controller)
        CanCreate = false;
        CanEdit = false;
        CanDelete = false;
        CanView = true; // Se chegou aqui, tem pelo menos permissão de consulta
    }
}
