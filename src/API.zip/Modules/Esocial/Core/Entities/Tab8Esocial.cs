﻿namespace RhSensoERP.Modules.Esocial.Core.Entities;

public class Tab8Esocial
{
    // PK
    public string Codigo { get; set; } = default!;
    public string Descricao { get; set; } = default!;
}
