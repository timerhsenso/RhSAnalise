﻿namespace RhSensoERP.Modules.Esocial.Core.Entities;

public class Tab4Esocial
{
    // PK
    public string Codigo { get; set; } = default!;     // tab4_codigo char(3)
    public string Descricao { get; set; } = default!;  // tab4_descricao
}
