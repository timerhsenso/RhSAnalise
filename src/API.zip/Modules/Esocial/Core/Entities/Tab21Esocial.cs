﻿namespace RhSensoERP.Modules.Esocial.Core.Entities;

public class Tab21Esocial
{
    // PK
    public string Codigo { get; set; } = default!;
    public string Descricao { get; set; } = default!;
}
