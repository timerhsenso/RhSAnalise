#nullable enable
using System;
namespace RhSensoERP.Shared.Core.Abstractions;
public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
}
