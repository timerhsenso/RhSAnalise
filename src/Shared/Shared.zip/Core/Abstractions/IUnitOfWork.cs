#nullable enable
using System.Threading;
using System.Threading.Tasks;
namespace RhSensoERP.Shared.Core.Abstractions;
public interface IUnitOfWork
{
    Task<int> SaveChangesAsync(CancellationToken ct = default);
}
