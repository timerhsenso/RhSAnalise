#nullable enable
namespace RhSensoERP.Shared.Core.Abstractions;
public interface IAggregateRoot { }
