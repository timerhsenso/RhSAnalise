#nullable enable
using System.Collections.Generic;
namespace RhSensoERP.Shared.Core.Abstractions;
public interface ICurrentUser
{
    string? Id { get; }
    string? Name { get; }
    string? Email { get; }
    IEnumerable<string> Roles { get; }
    bool IsAuthenticated { get; }
}
