#nullable enable
using System.Collections.Generic;
using System.Linq;
namespace RhSensoERP.Shared.Core.Primitives;
public abstract class ValueObject
{
    protected abstract IEnumerable<object?> GetEqualityComponents();
    public override bool Equals(object? obj)
        => obj is ValueObject other && GetEqualityComponents().SequenceEqual(other.GetEqualityComponents());
    public override int GetHashCode()
        => GetEqualityComponents().Aggregate(0, (hash, obj) => System.HashCode.Combine(hash, obj));
    public static bool operator ==(ValueObject? a, ValueObject? b) => Equals(a, b);
    public static bool operator !=(ValueObject? a, ValueObject? b) => !Equals(a, b);
}
