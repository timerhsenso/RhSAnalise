#nullable enable
namespace RhSensoERP.Shared.Core.Common;
public static class ErrorCodes
{
    public const string Validation   = "ERR_VALIDATION";
    public const string NotFound     = "ERR_NOT_FOUND";
    public const string Conflict     = "ERR_CONFLICT";
    public const string Forbidden    = "ERR_FORBIDDEN";
    public const string Unauthorized = "ERR_UNAUTHORIZED";
    public const string Internal     = "ERR_INTERNAL";
}
