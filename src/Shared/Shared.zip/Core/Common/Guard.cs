#nullable enable
using System;
namespace RhSensoERP.Shared.Core.Common;
public static class Guard
{
    public static T NotNull<T>(T? value, string name)
        => value is null ? throw new ArgumentNullException(name) : value;
    public static string NotNullOrWhiteSpace(string? value, string name)
        => string.IsNullOrWhiteSpace(value) ? throw new ArgumentException($"{name} cannot be empty.", name) : value;
    public static void Against(bool condition, string message)
    {
        if (condition) throw new ArgumentException(message);
    }
}
