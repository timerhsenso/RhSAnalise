#nullable enable
namespace RhSensoERP.Shared.Core.Common;

public class Result
{
    public bool IsSuccess { get; }
    public string? ErrorCode { get; }
    public string? ErrorMessage { get; }
    protected Result(bool isSuccess, string? code, string? message)
        => (IsSuccess, ErrorCode, ErrorMessage) = (isSuccess, code, message);
    public static Result Success() => new(true, null, null);
    public static Result Failure(string message, string? code = null) => new(false, code, message);
}

public sealed class Result<T> : Result
{
    public T? Value { get; }
    private Result(bool isSuccess, T? value, string? code, string? message)
        : base(isSuccess, code, message) => Value = value;
    public static Result<T> Success(T value) => new(true, value, null, null);
    public static Result<T> Failure(string message, string? code = null) => new(false, default, code, message);
}
