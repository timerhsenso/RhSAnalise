#nullable enable
using System.Collections.Generic;
namespace RhSensoERP.Shared.Core.Common;
public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; }
    public int Page { get; }
    public int PageSize { get; }
    public long TotalCount { get; }
    public PagedResult(IReadOnlyList<T> items, int page, int pageSize, long totalCount)
        => (Items, Page, PageSize, TotalCount) = (items, page, pageSize, totalCount);
}
